<?php
// No direct access to this file
defined('_JEXEC') or die('Restricted Access');
?>
<tr>
	<td colspan="3" align="center">
		Welcome to the Joomla! Solr extension for Joomla. This extension is created by Xlab in contribution to the Joomla open source project.<br />
		Please visit our website <a href="http://www.xlab.nl">Xlab</a> and tell us what you think about Joomla!	
		
	</td>
</tr>
<tr><td colspan="3"><center>This extension is created by <a href="http://www.xlab.nl">Xlab</a></center></td></tr>