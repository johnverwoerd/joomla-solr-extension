<?php
// No direct access to this file
defined('_JEXEC') or die('Restricted Access');
?>
<tr>
	<th colspan="3" style="text-align: right;">
		
	</th>
</tr>